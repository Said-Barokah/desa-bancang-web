<template>
<div class="mapouter">
    <div class="gmap_canvas"><iframe width="521" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=desa%20bancang%20bangkalan&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a>
    </div>
</div>
</template>


<style>
.mapouter {
    position: relative;
    text-align: right;
    height: 500px;
    width: 521px;
}
.gmap_canvas {
    overflow: hidden;
    background: none !important;
    height: 500px;
    width: 521px;
}
</style>
